# host="34.69.8.76"
host="localhost"
port=3306
user="admin"
database="tweeter"
password="data721tang"

X_Api_Key = "57WHq4ZjcDWSNiAIozIGNNzXKiPExaSL5CIoZ51rYk1YT"